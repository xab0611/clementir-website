HAPAG BAKEHOUSE WEBSITE STARTER
================================

Files:
- index.html       Main landing page
- css/style.css    Website styles
- images/          Place your own photos/logo here

HOW TO PREVIEW
1. Open the hapag-bakehouse-website folder in Visual Studio Code.
2. Open index.html.
3. Right-click and choose "Open with Live Server" (if installed), or open index.html in your browser.

IMPORTANT CUSTOMIZATION
- The proposal does not provide an exact street address, opening hours, phone number, product prices, or real customer reviews. Replace the clearly marked placeholders only with confirmed details.
- The order inquiry form is a front-end sample only. It does not send or store orders until connected to a form service or backend.
- Replace the emoji illustration placeholders with your own bakery photos in the Gallery and product sections.
- Review and understand the HTML/CSS, then make your own edits so you can explain the code during your lab check.

GITHUB COMMIT SUGGESTIONS
1. Create the initial project structure
2. Add the page header and navigation
3. Build the hero and menu sections
4. Add the pre-order and about sections
5. Style the gallery, reviews, and footer
6. Make the page responsive and polish styles
